# dnsblock – Rust-DNS-Adblocker

Ein Self-Hosted-Werbe- und Tracker-Blocker, komplett in Rust. Konzept:
die Stärken von **Pi-hole** und **AdGuard Home** kombiniert –
als **Unbound** vorgeschaltetet, rekursiver Upstream (DNSSEC-validierend).

**Status: Phase 1 (DNS-Daemon-Kern) fertig** – siehe [Roadmap](#roadmap).

## Features (Phase 1)

- DNS-Sinkhole für **UDP und TCP** (Port frei konfigurierbar, Tests nutzen Port 0)
- Blocklisten-Engine (`filter-engine`), gemischt verwendbar:
  - `hosts`-Format (`0.0.0.0 domain`)
  - Domänen-Listen (eine Domäne pro Zeile)
  - **AdGuard-Syntax-Subset**: `||domain^` blockiert Domäne + Subdomänen,
    `@@||domain^` als Allow-Eintrag (gewinnt gegen Block-Regeln)
  - Suffix-Match: `example.com` blockiert auch `a.b.example.com`
- Drei Block-Modi: `zero` (0.0.0.0 / NODATA, Pi-hole-artig), `nxdomain` (AdGuard-artig), `refused`
- Roh-Weiterleitung an den Upstream (byte-identisch, minimaler Overhead),
  TCP-Requests werden auch via TCP weitergeleitet (kein TC-Problem)
- Laufzeit-Statistik (total/blocked/forwarded/failed), sauberes Strg+C-Shutdown
- Upstream-Timeout → SERVFAIL an den Client (keine Hänger)
- Atomarer Datei-Austausch für Updates (getestet), 4-Tage-Intervall vorkonfiguriert

## Architektur

```
Clients (LAN) ──DNS UDP/TCP──> dnsblock (Rust) ──erlaubt──> Unbound (127.0.0.1:5353) ──rekursiv+DNSSEC──> Root-/TLD-Server
                                  │
                                  └──geblockt──> 0.0.0.0 / NXDOMAIN / REFUSED
```

Workspace:

| Crate            | Zweck                                                        |
|------------------|--------------------------------------------------------------|
| `filter-engine`  | Listen-Parser + Matcher (hosts, Domänen, AdGuard-Subset)     |
| `dnsblock`       | Daemon: UDP/TCP-Server, Resolver, Config, Updater, Tests    |

## Schnellstart

```sh
cargo run -- config/default.toml
```

Produktions-Ports (`:53`) in `config/default.toml` setzen; dafür sind root-Rechte
oder `CAP_NET_BIND_SERVICE` nötig (`setcap cap_net_bind_service=+ep dnsblock`).

### Statisches Binary (empfohlen für Router/NAS/Pi)

```sh
rustup target add x86_64-unknown-linux-musl
cargo build --release --target x86_64-unknown-linux-musl
# liegt dann unter target/x86_64-unknown-linux-musl/release/dnsblock
```

Vollständig statisch gelinkt – läuft auf jedem x86_64-Linux ohne Laufzeit-Abhängigkeiten.

## Unbound als Upstream

`/etc/unbound/unbound.conf.d/dnsblock-upstream.conf`:

```yaml
server:
    interface: 127.0.0.1
    port: 5353
    root-hints: "/var/lib/unbound/root.hints"
    auto-trust-anchor-file: "/var/lib/unbound/root.key"
    val-permissive-mode: no
```

So bleibt alles rekursiv und DNSSEC-validierend – auf öffentliche Resolver
(8.8.8.8 & Co.) wird vollständig verzichtet. Der Root-Hints- und
`root.key`-Update-Zyklus (Standard: alle 4 Tage, atomar + Reload) wird in
Phase 2 vom Daemon selbst gefahren (`updater.rs`-Gerüst ist vorhanden und
getestet).

## Tests

```sh
cargo test
```

- 8 Unit-Tests für die Filter-Engine (Parser, Suffix-Match, Allow-Vorrang, Müll)
- 9 Unit-Tests für den Daemon (Config, DNS-Antworten, Updater)
- 7 Integrationstests: echter UDP/TCP-Server mit gemocktem Upstream
  (Block, Subdomänen, Allow, Forward, SERVFAIL bei tottem Upstream, TCP, Statistik)

## Roadmap

- **Phase 1 (fertig):** DNS-Daemon-Kern, Filter-Engine, UDP/TCP, Statistik
- **Phase 2:** Unbound-Integration (Sidecar/Supervision), Root-Hints- und
  Blocklisten-Fetch über HTTPS (`reqwest` + rustls), atomarer Austausch + Reload,
  Per-Client-Regeln (Quell-IP)
- **Phase 3:** Query-Log + Statistik-Backend (`redb`/SQLite), REST-API + Web-UI
  (`axum`), DoH/DoT-Endpunkt
- **Phase 4:** YouTube-Modul – Begleit-Extension (MV3 + Firefox), die ihr
  Regelwerk vom Daemon bezieht: Player-Response-Filter (adPlacements entfernen),
  **gelbe Werbebalken in Timeline/Feed ausblenden**, Auto-Skip.
  Reines DNS blockt YouTube-Ads nicht (gleiche Domains wie die Videos).

## Hinweise

- YouTube-/Google-Video-Ads kommen von `googlevideo.com` – derselben Infrastruktur
  wie die Inhalte. DNS-Blocking würde die Videos selbst zerstören; deshalb
  übernimmt Phase 4 die clientseitige Filterung.
- Lizenz: MIT
