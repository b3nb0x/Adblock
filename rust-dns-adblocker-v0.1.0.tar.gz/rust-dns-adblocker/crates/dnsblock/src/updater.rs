//! Root-Hints-/Blocklisten-Updater (Phase-2-Skelett).
//!
//! Der 4-Tage-Zyklus für die Root-Hints (`named.cache` von internic.net)
//! und `root.key` (via `unbound-anchor`) ist konfiguriert; der atomare
//! Austausch ist implementiert und getestet. Der Netzwerk-Fetch
//! (HTTPS) folgt in Phase 2 – dort wird `reqwest` + rustls ergänzt.

use std::path::Path;
use std::time::{Duration, SystemTime};

/// Offizielle Quelle der Root-Hints.
pub const ROOT_HINTS_URL: &str = "https://www.internic.net/domain/named.cache";

/// Schreibt Daten atomar nach `path` (temp + rename, gleiches Dateisystem).
/// Ein Absturz mid-write kann die bestehende Datei nicht zerstören.
pub fn atomic_write(path: &Path, data: &[u8]) -> std::io::Result<()> {
    let tmp = path.with_extension("new");
    std::fs::write(&tmp, data)?;
    std::fs::rename(&tmp, path)
}

/// Intervall des Root-Hints-Updates (Standard: 4 Tage).
pub fn root_hints_interval(days: u32) -> Duration {
    Duration::from_secs(u64::from(days) * 24 * 60 * 60)
}

/// Zeitpunkt des nächsten geplanten Updates.
pub fn next_deadline(last_update: SystemTime, days: u32) -> SystemTime {
    last_update + root_hints_interval(days)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn atomic_write_replaces_content_and_leaves_no_tmp() {
        let dir = std::env::temp_dir().join("dnsblock-updater-test");
        std::fs::create_dir_all(&dir).unwrap();
        let target = dir.join("named.cache");
        std::fs::write(&target, b"alt").unwrap();
        atomic_write(&target, b"neu").unwrap();
        assert_eq!(std::fs::read(&target).unwrap(), b"neu");
        assert!(!dir.join("named.new").exists());
    }

    #[test]
    fn interval_is_four_days() {
        assert_eq!(root_hints_interval(4), Duration::from_secs(4 * 24 * 60 * 60));
    }
}
