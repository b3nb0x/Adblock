//! UDP/TCP-DNS-Server mit Sinkhole-Logik und Statistik.

use crate::config::{BlockMode, ResolvedConfig};
use crate::dns;
use crate::resolver::Resolver;
use filter_engine::FilterEngine;
use std::net::SocketAddr;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream, UdpSocket};
use tokio::task::JoinHandle;

/// Laufzeitzähler.
#[derive(Debug, Default)]
pub struct Stats {
    pub total: AtomicU64,
    pub blocked: AtomicU64,
    pub forwarded: AtomicU64,
    pub failed: AtomicU64,
}

impl Stats {
    pub fn summary(&self) -> String {
        let (total, blocked, forwarded, failed) = (
            self.total.load(Ordering::Relaxed),
            self.blocked.load(Ordering::Relaxed),
            self.forwarded.load(Ordering::Relaxed),
            self.failed.load(Ordering::Relaxed),
        );
        format!(
            "Anfragen: {total}, geblockt: {blocked}, weitergeleitet: {forwarded}, fehlgeschlagen: {failed}"
        )
    }
}

/// Startet UDP- und TCP-Listener. Beide binden sofort (Port 0 = ephemeral,
/// nützlich für Tests) und laufen als Hintergrund-Tasks.
pub async fn start(
    engine: Arc<FilterEngine>,
    cfg: ResolvedConfig,
) -> std::io::Result<ServerHandle> {
    let udp = UdpSocket::bind(cfg.listen_udp).await?;
    let udp_addr = udp.local_addr()?;
    let tcp = TcpListener::bind(cfg.listen_tcp).await?;
    let tcp_addr = tcp.local_addr()?;

    let resolver = Arc::new(Resolver::new(cfg.upstream));
    let stats = Arc::new(Stats::default());
    let mode = cfg.block_mode;

    let udp_task =
        tokio::spawn(udp_loop(udp, engine.clone(), resolver.clone(), mode, stats.clone()));
    let tcp_task = tokio::spawn(tcp_loop(tcp, engine, resolver, mode, stats.clone()));

    Ok(ServerHandle {
        udp: udp_addr,
        tcp: tcp_addr,
        stats,
        tasks: vec![udp_task, tcp_task],
    })
}

/// Handle auf den laufenden Server (Adressen + Statistik-Zugriff).
#[derive(Debug)]
pub struct ServerHandle {
    pub udp: SocketAddr,
    pub tcp: SocketAddr,
    pub stats: Arc<Stats>,
    tasks: Vec<JoinHandle<()>>,
}

impl ServerHandle {
    /// Stoppt alle Server-Tasks.
    pub fn shutdown(&self) {
        for t in &self.tasks {
            t.abort();
        }
    }
}

async fn udp_loop(
    sock: UdpSocket,
    engine: Arc<FilterEngine>,
    resolver: Arc<Resolver>,
    mode: BlockMode,
    stats: Arc<Stats>,
) {
    let sock = Arc::new(sock);
    loop {
        let mut buf = vec![0u8; 4096];
        if let Ok((n, peer)) = sock.recv_from(&mut buf).await {
            let resp =
                handle_datagram(&buf[..n], &engine, &resolver, mode, &stats, false).await;
            if let Some(bytes) = resp {
                let _ = sock.send_to(&bytes, peer).await;
            }
        }
    }
}

async fn tcp_loop(
    listener: TcpListener,
    engine: Arc<FilterEngine>,
    resolver: Arc<Resolver>,
    mode: BlockMode,
    stats: Arc<Stats>,
) {
    loop {
        if let Ok((stream, _peer)) = listener.accept().await {
            let engine = engine.clone();
            let resolver = resolver.clone();
            let stats = stats.clone();
            tokio::spawn(async move {
                handle_tcp_conn(stream, engine, resolver, mode, stats).await;
            });
        }
    }
}

async fn handle_tcp_conn(
    mut stream: TcpStream,
    engine: Arc<FilterEngine>,
    resolver: Arc<Resolver>,
    mode: BlockMode,
    stats: Arc<Stats>,
) {
    loop {
        let mut lenbuf = [0u8; 2];
        if stream.read_exact(&mut lenbuf).await.is_err() {
            return; // EOF oder Fehler: Verbindung beenden
        }
        let len = u16::from_be_bytes(lenbuf) as usize;
        if len == 0 {
            return;
        }
        let mut req = vec![0u8; len];
        if stream.read_exact(&mut req).await.is_err() {
            return;
        }
        // TCP-Transport auch Richtung Upstream verwenden (korrekt für
        // Antworten > 512 Bytes, TC-Flag wird so nie nötig)
        let resp =
            handle_datagram(&req, &engine, &resolver, mode, &stats, true).await;
        let Some(resp) = resp else { return };
        let out_len = match u16::try_from(resp.len()) {
            Ok(l) => l,
            Err(_) => return,
        };
        if stream.write_all(&out_len.to_be_bytes()).await.is_err()
            || stream.write_all(&resp).await.is_err()
        {
            return;
        }
    }
}

/// Kernlogik: parst die Anfrage, entscheidet block/forward und baut die Antwort.
/// `prefer_tcp` wählt den Transport Richtung Upstream.
async fn handle_datagram(
    raw: &[u8],
    engine: &FilterEngine,
    resolver: &Resolver,
    mode: BlockMode,
    stats: &Stats,
    prefer_tcp: bool,
) -> Option<Vec<u8>> {
    let req = match dns::parse_request(raw) {
        Some(m) => m,
        None => {
            stats.failed.fetch_add(1, Ordering::Relaxed);
            return None;
        }
    };
    stats.total.fetch_add(1, Ordering::Relaxed);

    let name = dns::qname(&req);
    let blocked = name.as_deref().map(|n| engine.is_blocked(n)).unwrap_or(false);

    if blocked {
        stats.blocked.fetch_add(1, Ordering::Relaxed);
        tracing::debug!(qname = name.as_deref().unwrap_or("?"), "blockiert");
        return Some(dns::blocked_response(&req, mode));
    }

    let forwarded = if prefer_tcp {
        resolver.resolve_tcp(raw).await
    } else {
        resolver.resolve_udp(raw).await
    };

    match forwarded {
        Some(bytes) => {
            stats.forwarded.fetch_add(1, Ordering::Relaxed);
            Some(bytes)
        }
        None => {
            stats.failed.fetch_add(1, Ordering::Relaxed);
            tracing::warn!(qname = name.as_deref().unwrap_or("?"), "Upstream-Timeout");
            Some(dns::servfail_response(&req))
        }
    }
}
