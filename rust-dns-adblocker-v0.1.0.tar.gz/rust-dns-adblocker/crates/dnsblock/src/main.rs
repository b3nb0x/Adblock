//! `dnsblock` – Startpunkt des DNS-Sinkhole-Daemons.

use std::time::Duration;
use dnsblock::config::Config;
use dnsblock::server;

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "info".into()),
        )
        .init();

    let cfg_path = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "config/default.toml".to_string());

    let raw = match Config::from_path(&cfg_path) {
        Ok(c) => c,
        Err(e) => {
            tracing::error!(config = %cfg_path, error = %e, "Konfiguration ungültig");
            std::process::exit(1);
        }
    };
    let resolved = match raw.resolve() {
        Ok(r) => r,
        Err(e) => {
            tracing::error!(error = %e, "Adressen in der Konfiguration ungültig");
            std::process::exit(1);
        }
    };

    let loaded = match dnsblock::load_engine(&resolved) {
        Ok(l) => l,
        Err(e) => {
            tracing::error!(error = %e, "Blocklisten konnten nicht geladen werden");
            std::process::exit(1);
        }
    };
    tracing::info!(
        domains = loaded.engine.blocked_count(),
        skipped = loaded.stats.skipped,
        "Filter-Engine bereit"
    );

    if resolved.root_hints_update_days > 0 {
        tracing::info!(
            days = resolved.root_hints_update_days,
            url = dnsblock::updater::ROOT_HINTS_URL,
            "Root-Hints-Auto-Update aktiviert (Fetch folgt in Phase 2)"
        );
    }

    let handle = match server::start(loaded.engine, resolved).await {
        Ok(h) => h,
        Err(e) => {
            tracing::error!(error = %e, "Server konnte nicht starten (Port belegt?)");
            std::process::exit(1);
        }
    };

    tracing::info!(udp = %handle.udp, tcp = %handle.tcp, "dnsblock lauscht");
    tracing::info!("Beenden mit Strg+C");

    tokio::signal::ctrl_c().await.expect("Signal-Handler");
    tracing::info!(stats = handle.stats.summary(), "Shutdown");
    handle.shutdown();
    // kurze Gnadenfrist für ausstehende Antworten
    tokio::time::sleep(Duration::from_millis(100)).await;
}
