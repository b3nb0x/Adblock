//! Upstream-Resolver: leitet Anfragen roh (byte-identisch) an den
//! Upstream weiter – Standard: lokales Unbound auf 127.0.0.1:5353.

use std::net::SocketAddr;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpStream, UdpSocket};
use tokio::time::timeout;

const UPSTREAM_TIMEOUT: Duration = Duration::from_secs(3);
const MAX_DNS_MSG: usize = 65_535;

#[derive(Debug, Clone)]
pub struct Resolver {
    upstream: SocketAddr,
}

impl Resolver {
    pub fn new(upstream: SocketAddr) -> Self {
        Self { upstream }
    }

    /// UDP-Forward. Liefert `None` bei Timeout/Fehler (Aufrufer sendet SERVFAIL).
    pub async fn resolve_udp(&self, query: &[u8]) -> Option<Vec<u8>> {
        let sock = UdpSocket::bind(("0.0.0.0", 0)).await.ok()?;
        sock.connect(self.upstream).await.ok()?;
        let fut = async {
            sock.send(query).await.ok()?;
            let mut buf = vec![0u8; 4096];
            let n = sock.recv(&mut buf).await.ok()?;
            buf.truncate(n);
            Some(buf)
        };
        timeout(UPSTREAM_TIMEOUT, fut).await.ok().flatten()
    }

    /// TCP-Forward (2-Byte-Längen-Framing, für truncierte Antworten).
    pub async fn resolve_tcp(&self, query: &[u8]) -> Option<Vec<u8>> {
        let mut stream = TcpStream::connect(self.upstream).await.ok()?;
        let fut = async {
            let len = u16::try_from(query.len()).ok()?;
            stream.write_all(&len.to_be_bytes()).await.ok()?;
            stream.write_all(query).await.ok()?;
            let mut lenbuf = [0u8; 2];
            stream.read_exact(&mut lenbuf).await.ok()?;
            let len = u16::from_be_bytes(lenbuf) as usize;
            if len > MAX_DNS_MSG {
                return None;
            }
            let mut resp = vec![0u8; len];
            stream.read_exact(&mut resp).await.ok()?;
            Some(resp)
        };
        timeout(UPSTREAM_TIMEOUT, fut).await.ok().flatten()
    }
}
