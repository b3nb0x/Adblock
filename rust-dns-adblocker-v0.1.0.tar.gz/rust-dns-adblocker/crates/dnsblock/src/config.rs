//! Konfiguration (TOML) des Daemons.

use std::net::SocketAddr;
use std::path::{Path, PathBuf};
use serde::Deserialize;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum ConfigError {
    #[error("Konfigurationsdatei konnte nicht gelesen werden: {0}")]
    Io(#[from] std::io::Error),
    #[error("TOML konnte nicht geparst werden: {0}")]
    Parse(#[from] toml::de::Error),
    #[error("Ungültige Adresse '{addr}': {source}")]
    Addr { addr: String, source: std::net::AddrParseError },
}

/// Antwort-Verhalten für blockierte Anfragen.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum BlockMode {
    /// A-Record 0.0.0.0 (Pi-hole-Verhalten), andere Typs: NODATA.
    #[default]
    Zero,
    /// NXDOMAIN (AdGuard-Home-Verhalten).
    NxDomain,
    /// REFUSED zurückmelden.
    Refused,
}

/// Rohe Konfiguration aus der TOML-Datei.
#[derive(Debug, Deserialize)]
pub struct Config {
    /// UDP-Listen-Adresse, z. B. "0.0.0.0:53".
    pub listen_udp: String,
    /// TCP-Listen-Adresse, z. B. "0.0.0.0:53".
    pub listen_tcp: String,
    /// Upstream-Resolver, Standard: lokales Unbound "127.0.0.1:5353".
    pub upstream: String,
    /// Antwort-Verhalten für Block-Treffer.
    #[serde(default)]
    pub block_mode: BlockMode,
    /// Blocklisten-Dateien (hosts-, Domänen- oder AdGuard-Format).
    #[serde(default)]
    pub blocklists: Vec<PathBuf>,
    /// Allowlisten-Dateien.
    #[serde(default)]
    pub allowlists: Vec<PathBuf>,
    /// Root-Hints-Auto-Update-Intervall in Tagen (0 = aus). Standard: 4.
    #[serde(default = "default_root_hints_days")]
    pub root_hints_update_days: u32,
}

fn default_root_hints_days() -> u32 {
    4
}

impl Config {
    /// Liest die Konfiguration aus einer Datei.
    pub fn from_path(path: impl AsRef<Path>) -> Result<Self, ConfigError> {
        let raw = std::fs::read_to_string(path)?;
        Self::from_str(&raw)
    }

    /// Parst die Konfiguration aus einem String.
    pub fn from_str(raw: &str) -> Result<Self, ConfigError> {
        Ok(toml::from_str(raw)?)
    }

    /// Löst die Adressen auf und erzeugt die Laufzeit-Konfiguration.
    pub fn resolve(&self) -> Result<ResolvedConfig, ConfigError> {
        let parse = |s: &str| -> Result<SocketAddr, ConfigError> {
            s.parse()
                .map_err(|source| ConfigError::Addr { addr: s.to_string(), source })
        };
        Ok(ResolvedConfig {
            listen_udp: parse(&self.listen_udp)?,
            listen_tcp: parse(&self.listen_tcp)?,
            upstream: parse(&self.upstream)?,
            block_mode: self.block_mode,
            blocklists: self.blocklists.clone(),
            allowlists: self.allowlists.clone(),
            root_hints_update_days: self.root_hints_update_days,
        })
    }
}

/// Aufgelöste (validierte) Konfiguration für den Serverbetrieb.
#[derive(Debug, Clone)]
pub struct ResolvedConfig {
    pub listen_udp: SocketAddr,
    pub listen_tcp: SocketAddr,
    pub upstream: SocketAddr,
    pub block_mode: BlockMode,
    pub blocklists: Vec<PathBuf>,
    pub allowlists: Vec<PathBuf>,
    pub root_hints_update_days: u32,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_default_config() {
        let raw = r#"
listen_udp = "127.0.0.1:5300"
listen_tcp = "127.0.0.1:5300"
upstream = "127.0.0.1:5353"
block_mode = "nxdomain"
blocklists = ["a.txt"]
"#;
        let cfg = Config::from_str(raw).unwrap();
        let res = cfg.resolve().unwrap();
        assert_eq!(res.listen_udp, "127.0.0.1:5300".parse::<SocketAddr>().unwrap());
        assert_eq!(res.block_mode, BlockMode::NxDomain);
        assert_eq!(res.root_hints_update_days, 4);
        assert!(res.allowlists.is_empty());
    }

    #[test]
    fn defaults_block_mode_zero() {
        let raw = r#"
listen_udp = "0.0.0.0:53"
listen_tcp = "0.0.0.0:53"
upstream = "127.0.0.1:5353"
"#;
        let cfg = Config::from_str(raw).unwrap();
        assert_eq!(cfg.block_mode, BlockMode::Zero);
    }

    #[test]
    fn invalid_address_is_rejected() {
        let raw = r#"
listen_udp = "keine-adresse"
listen_tcp = "0.0.0.0:53"
upstream = "127.0.0.1:5353"
"#;
        let cfg = Config::from_str(raw).unwrap();
        assert!(cfg.resolve().is_err());
    }
}
